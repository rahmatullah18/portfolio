const sertifikat = [
  {
    title: "Teknik Promosi Web melalui Media Social Google, Facebook dan Instagram",
    tanggal: "4-5 Agustus 2022",
    url: "https://drive.google.com/file/d/1rN0mg_V6aqpQLHUf4Mu9MLRMFwQ_3Mr2/view?usp=sharing",
    tempat: "Kantor Bupati Jeneponto"
  },
  {
    title: "Praktek Kerja Lapangan",
    tanggal: "13 Sebtember - 12 November 2021",
    url: "https://drive.google.com/file/d/181-Lesu2j5_XwrslOoCV2Qz-nNHChkX0/view?usp=sharing",
    tempat: "Kantor Bupati Jeneponto"
  }
]

const sertifikatContent = {
  sertifikat
}

export default sertifikatContent