const title = "Rahmatullah Ashar"

const listNavbar = [
    { name: "Home", address: "/" },
    { name: "Project", address: "/projects" },
    { name: "Skills & Experience", address: "/skills&experience" },
]

const contentNavbar = {
    title,
    listNavbar
}

export default contentNavbar